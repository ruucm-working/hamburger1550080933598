import { Data, animate, Override, Animatable } from 'framer'

import { log } from 'ruucm-util'

const data = Data({
  //lineOne
  //   scale: Animatable(1),
  rightOne: Animatable(0),
  topOne: Animatable(0),
  rotationOne: Animatable(0),
  widthOne: Animatable(21),

  //lineThree
  bottomThree: Animatable(0),
  rightThree: Animatable(0),
  rotationThree: Animatable(0),
  widthThree: Animatable(28),

  //lineTwo
  widthTwo: Animatable(33),
  rightTwo: Animatable(0),
  leftTwo: Animatable(0),
})

// switch
var isOpened = false

// anim options
const springOptionsOne = {
  tension: 500,
  friction: 20,
}

export const Open: Override = () => {
  return {
    // scale: data.scale,
    async onTap() {
      if (!isOpened) {
        log('open !')

        animate.easeInOut(data.widthOne, 45.5)

        animate.easeInOut(data.topOne, -3)
        animate.easeInOut(data.bottomThree, -3)

        animate.easeInOut(data.widthThree, 45.5)

        // animate.spring(data.rightOne, 33 * (1 - Math.sqrt(2)), springOptionsOne)

        // animate.spring(
        //   data.rightThree,
        //   33 * (1 - Math.sqrt(2)),
        //   springOptionsOne
        // )

        animate.spring(data.rotationOne, 45)
        animate.spring(data.rotationThree, -45)

        // hide lineTwo
        animate.easeIn(data.leftTwo, 2, {
          duration: 0.8,
        })
        animate.easeIn(data.rightTwo, 30, {
          duration: 0.8,
        })
        // animate.easeInOut(data.widthTwo, 0)
      } else {
        log('close !')

        // lineOne
        await animate.spring(data.rotationOne, 0, springOptionsOne).finished
        await animate.spring(data.rightOne, 0, springOptionsOne).finished
        await animate.spring(data.widthOne, 21, springOptionsOne).finished

        // lineThree
        animate.spring(data.rightThree, 0, springOptionsOne)
      }
      isOpened = !isOpened
    },
  }
}

// Lines

export const lineOne: Override = () => {
  return {
    right: data.rightOne,
    top: data.topOne,
    rotation: data.rotationOne,
    width: data.widthOne,
    originX: 0,
    originY: 0,
  }
}

export const lineThree: Override = () => {
  return {
    right: data.rightThree,
    bottom: data.bottomThree,
    rotation: data.rotationThree,
    width: data.widthThree,
    originX: 0,
    originY: 0,
  }
}

export const lineTwo: Override = () => {
  return {
    width: data.widthTwo,
    right: data.rightTwo,
    left: data.leftTwo,
  }
}
